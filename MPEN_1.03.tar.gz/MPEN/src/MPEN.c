/*
 *  bayes_shrinkage.c_qtraits
 *  
 *  Updated by Ting-Huei Chen April 28 2011
 *
 *
 */

#include <R_ext/Applic.h>
#include <R_ext/PrtUtil.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <R.h>
#include <Rmath.h>
#include "utility.h"
#include "MPEN.h"



/*********************************************************************
 *
 * IMALr
 *
 * The Iterative Adaptive Lasso, with X input from R
 *
 *********************************************************************/

void MPENr(double* RY, double* RX,double* RbInit, double* bSample, double* Rb0,
		  double* Rdelta1, double* delta2, double* tau1, double* tau2, int* dims, double* Repsilon, int* nIter, 
		  int* b_update_order, double* score, int* scoNA,double* RBIC_gamma,
		  int* Ridc, char** RChoosing_Tuning1, char** RChoosing_Tuning2, double* score2use, double* delta1use, 
		  double* delta2use, double* tau1use, double* tau2use,  
		  double* Rv0m, double* Rb0m, int* RJ, int* I)
{

  double **Y;
  int n = dims[0];
  int q = dims[12];
  int nd= dims[8];
  int wi = dims[10];
  int p = dims[1];
  
  /* reorganize vector into matrix */
  reorg(RY, &Y, q, n);

  
  double **X, **bInit, **RbSample, **v0m, **b0m, **delta1;
  int **J;
  reorg_int(RJ, &J, p, q);
  
  /* reorganize vector into matrix */
 
  reorg(RX, &X, p, n);
  reorg(Rdelta1, &delta1, nd, q);
 
  reorg(RbInit, &bInit, p, q);
  reorg(bSample, &RbSample, p, q);
  reorg(Rv0m, &v0m, q, nd);
  reorg(Rb0m, &b0m, q, nd); 
  
  
  

  MPEN(Y, X,bInit, RbSample, Rb0, delta1, delta2, tau1, tau2, dims, Repsilon, nIter, 
    b_update_order, score, scoNA, RBIC_gamma, Ridc, RChoosing_Tuning1, RChoosing_Tuning2, 
    score2use, delta1use, delta2use, tau1use, tau2use,  v0m, b0m, J, I);
}



/*********************************************************************
 *
 * MPEN
 *
 * The Multivariate Iterative Adaptive Lasso
 *
 *********************************************************************/

void MPEN(double** Y, double** X,double** bInit, double** RbSample, double* Rb0,
  double** delta1, double* delta2, double* tau1, double* tau2, int* dims, double* Repsilon, int* nIter, 
  int* b_update_order, double* score, int* scoNA, 
  double* RBIC_gamma, int* Ridc, char** RChoosing_Tuning1, char** RChoosing_Tuning2, double* score2use, double* delta1use, 
  double* delta2use, double* tau1use, double* tau2use,  double** v0m, double** b0m, int** J, int * I 
  )
{
  int i, j, k, w, n, p, L, init_b, n_b2use, q, i1, kk, i2, *Bj, s1, count, j1,**BSindex;
  int Nmax, found=0, n_delta1, n_delta2, n_tau1, n_tau2, p_max, k1, k2, k3, k4, ncv, *num_b, num_i;
  int *XXindex, ii, g, gene, upperGroupSize, IMAL_only, num_Group, *Group_Size;
  double xkj, *b0, bij_bar, *v0, sj, tmp, epsilon, *Y1, bj0, tmp4;
  double **b, **b1, **v, **res, *Xj2, resi,tmp2, *v2, tmp3, *B_J, *X_k, *Y_k, *res_k;
  double  BIC_gamma = *RBIC_gamma, I1, I2, **testRes, *vecBs;
  char* Choosing_Tuning1 = RChoosing_Tuning1[0];
  double varY;


/* create output B matrix, with dimenstion q by upperb*numTunings
 */
  double **output_Bestimate;
  int **output_Bindex, upperb;
  
  tmp     = 0.0;
  tmp2    = 0.0;
  q       = dims[12];
  n_tau1  = dims[13];
  n_tau2  = dims[14];
  n       = dims[0];
  p       = dims[1];
  L       = dims[2];
  Nmax    = dims[3];
  init_b  = dims[4];
  n_delta1    = dims[8];
  n_delta2    = dims[9];
  p_max   = dims[10];
  ncv     = dims[11];
  epsilon = *Repsilon;
  upperb = dims[5];

  
  B_J     = (double *)calloc(p, sizeof(double));
  Y1      = (double *)calloc(n, sizeof(double));
  v0      = (double *)calloc(q, sizeof(double));
  v2      = (double *)calloc(p, sizeof(double));
  b0      = (double *)calloc(q, sizeof(double));
  b       = (double **)calloc(p, sizeof(double*));
  b1      = (double **)calloc(p, sizeof(double*));
  v       = (double **)calloc(p, sizeof(double*));
  Xj2     = (double *)calloc(p, sizeof(double));
  X_k     = (double *)calloc(p, sizeof(double));
  Y_k     = (double *)calloc(q, sizeof(double));
  res_k   = (double *)calloc(q, sizeof(double));
  
  Bj          = (int *)calloc(p, sizeof(int)); 
  XXindex     = (int *)calloc(p_max*upperGroupSize, sizeof(int)); 
  BSindex     = (int **)calloc(p, sizeof(int*)); 
  
  output_Bindex = (int **)calloc(q, sizeof(int*));
  output_Bestimate = (double **)calloc(q, sizeof(double*));

  
  for(j=0; j<p;j++){
    b[j]      =(double *)calloc(q,sizeof(double));  
    b1[j]     =(double *)calloc(q,sizeof(double));  
    v[j]      =(double *)calloc(q,sizeof(double));
    BSindex[j]= (int *)calloc(q,sizeof(int));       
  }         
  
  for (i=0; i<q; i++){
    output_Bindex[i]    = (int *)calloc(upperb,sizeof(int)); 
    output_Bestimate[i] = (double *)calloc(upperb,sizeof(double));
  } 
  
  testRes     = (double **) malloc(upperGroupSize * sizeof(double*));
	testRes[0]  = (double *) calloc(upperGroupSize*n, sizeof(double));	
	if(testRes[0] == NULL){ error("fail to allocate memory of size %d\n", upperGroupSize*n); }
	for(i=1; i<upperGroupSize; i++){
		testRes[i] = testRes[0] + i*n;
	}
  
  res     = (double **) malloc(q * sizeof(double*));
	res[0]  = (double *) calloc(q*n, sizeof(double));	
	if(res[0] == NULL){ error("fail to allocate memory of size %d\n", q*n); }
	for(i=1; i<q; i++){
		res[i] = res[0] + i*n;
	}
  
  
  

  
  /**
   * Calculate Xj2
   * sum square for each marker, i.e., each column of X
   * note this quantity is re-calculated if we use cv to 
   * select delta and tau
   */
  for(j=0; j<p; j++){
    Xj2[j] = 0.0;
    for(k=0; k<n; k++){
      xkj = X[j][k];
      Xj2[j] += xkj*xkj;
    }
  }

  /* MPEN calculation */
  
  for(k1=0; k1 < n_delta1; k1++){
    
    /**
     * step 1. Initialization
     */
    
    /*Initialization of v0*/
    
    for(i=0;i<q;i++){
      for(k=0;k<n;k++){
        Y1[k]=Y[i][k];
      }
      v0[i] = var(Y1, n);  
      if(i==1){
        varY = v0[i];
      }
    } 
    
    /*BSindex is a p*q int matrix: 1 if bji not zero, 0 if else
     B_J is the summation of |bji| across i
     */
    
    if(init_b){                      
      for(j=0; j<p; j++){
        for(i=0; i<q; i++){                    
          b[j][i] = b1[j][i] = bInit[j][i];               
          BSindex[j][i]=1;
        }   
      } 
      for(j=0; j<p; j++){
        bj0 = 0.0;
        for(i=0; i<q; i++){
          bj0=bj0+fabs(b[j][i]); 	    
        }
        B_J[j]=bj0;
      }        
    }else{
      for (i=0; i<q; i++){
        for(j=0; j<p; j++){                             
          b[j][i] = b1[j][i]=0.0;
          BSindex[j][i]=0;
        }           
      }  
      for(j=0; j<p; j++){        
        B_J[j] = 0.0;
      }
    }      
    
    
    
    /* kk is used to check the convergence */
    kk = 0;
    
    /* initialize residuals */
    
    for (i=0; i<q; i++){
      resi = 0.0;               
      for(k=0; k<n; k++){
        resi = resi + Y[i][k];
      }  
      b0[i] = resi/n;
    }
    for(i=0; i<q; i++){ 
      for(k=0; k<n; k++){
        res[i][k] = Y[i][k]-b0[i];
      }
    }
    
    /* Iteration begins*/
    for(w=1; w<=Nmax; w++){
      
      /**
       * step Update bji
       */
      
      for(i1=0; i1<q; i1++){
        i=I[i1];
        
        /* remove the effect of Xjk from the residual*/
        
        for(j1=0; j1<p; j1++){
          j=J[j1][i];                     
          if(BSindex[j][i]==1){
            for(k=0; k<n; k++){                       
              res[i][k] = res[i][k] + X[j][k]*b[j][i];                       
            }         
          }
          bij_bar = 0.0;
          
          for(k=0; k<n; k++){                                        
            bij_bar += X[j][k]*res[i][k];                                        
          }
          
          bij_bar /= (Xj2[j]);
          sj = 1/(Xj2[j]);                               
          tmp = sj*( ((1.0+delta1[k1][i])/(fabs(b1[j][i]) + tau1[k1])) + ((1.0+delta2[k1])/(B_J[j] + tau2[k1])) );
          
          if(bij_bar > tmp){
            b[j][i] = bij_bar - tmp;
            BSindex[j][i]=1;
            
          }else if(bij_bar < -tmp){
            b[j][i] = bij_bar + tmp;
            BSindex[j][i]=1;
            
          }else{
            b[j][i] = 0.0;
            BSindex[j][i]=0;
          }
          
          
          /* add the effect of Xj back into the residual */
          
          if(BSindex[j][i]==1){           
            for(k=0; k<n; k++){                       
              res[i][k] = res[i][k] - X[j][k]*b[j][i];                        
            }               
          }
        }
      }
      
      for (i=0; i<q; i++){
        resi = 0.0;
        for(k=0; k<n; k++){
          resi = resi + res[i][k];
        }  
        b0[i] = resi/n+b0[i];
      }
      
      
      /**
       * step  Update v0, i.e. sigma^2
       */
      
      for(i=0; i<q; i++){
        v0[i]=0.0;
        for(k=0; k<n; k++){
          v0[i] += res[i][k]*res[i][k];
        }  
        v0[i] = v0[i]/n;
      }
      
      
      /**
       * check convergence
       */          
      
      found = 0;         
      for(j=0; j<p; j++){  
        for(i=0; i<q; i++){
          if(fabs(b1[j][i] - b[j][i]) > epsilon){
            found = 1;
            kk = 0;
            break;
          }
        }
      }
      
      if(found == 0){
        kk += 1;
        if(kk>=L){
          break; // converged :)
        }
      }
      
      for(j=0; j<p; j++){
        bj0=0.0;            
        for(i=0; i<q; i++){
          bj0=bj0+fabs(b[j][i]);   
          b1[j][i] = b[j][i];        	
        } 
        B_J[j] = bj0;         
      }
      
    }
    /*Rprintf("check2");*/
    *nIter = w;
    
    
      for(i=0; i<q; i++){
        Rb0[i] = b0[i];
        for(j=0; j<p; j++){
          RbSample[j][i] = b[j][i]; 
        }
      }    
    
        
    

    /*if(n_b2use == 0 || n_b2use >= p_max){    
     for(i=0; i<q; i++){
     Rb0[i] = b0[i];
     for(j=0; j<p; j++){
     RbSample[j][i] = b[j][i]; 
     }
     }       			
     continue;
     }*/
    
    
    
    
    
    
    
  }
  
  for(j=0; j<p;j++){
    free(b[j]);  
    free(b1[j]);  
    free(v[j]);
    free(BSindex[j]);       
  }         
  
  for (i=0; i<q; i++){
    free(output_Bindex[i]); 
    free(output_Bestimate[i]);
  } 

  
  free(b);
  free(v);
  free(res[0]);
  free(res);
  free(testRes[0]);
  free(testRes);
  free(Xj2);
  free(b1);
  free(BSindex);
  free(b0);
  free(B_J);
  free(X_k);
  free(Y1);
 
  free(output_Bindex);
  free(output_Bestimate);
  free(v0);
  free(v2);
  free(Y_k);
  free(res_k);
  free(Bj);
  free(XXindex);
  
  
  


 
 
  
}
/*********************************************************************
 * end of MPEN
 *********************************************************************/



