
void MPEN(double** Y, double** X,double** bInit, double** RbSample, double* Rb0,
           double** delta1, double* delta2, double* tau1, double* tau2, int* dims, double* Repsilon, int* nIter, 
           int* b_update_order, double* score, int* scoNA, 
           double* RBIC_gamma, int* Ridc, char** RChoosing_Tuning1, char** RChoosing_Tuning2s, double* score2use, double* delta1use, 
           double* delta2use, double* tau1use, double* tau2use,  double** v0m, double** b0m, int** J, int * I);
