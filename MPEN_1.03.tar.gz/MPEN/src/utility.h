
void reorg(double *v, double ***m, int nrow, int ncol);
void reorg_int(int *v, int ***m, int nrow, int ncol);
double mean(double *v, int size);
double mean_j(double **v, int j, int size);
double var(double *v, int size);
void rsample(int* per, int n);
double rinvGauss1(double mu, double lambda);
void rinvGauss(double *x, int* n, double* mu, double* lambda);
void dinvGauss(double* y, double* x, int* n, double* Rmu, double* Rlambda);
void readtext(double **matrix, char *str, int nrows, int ncols, int offsetrow, int offsetcol, int transpose);
