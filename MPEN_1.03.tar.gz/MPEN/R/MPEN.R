`MPEN` <-
function(Y, X, b=NULL, delta1=NULL,delta2 = NULL,tau1 = NULL, tau2 = NULL, Choosing_Tuning1="BIC", BIC.gamma=0, pMax=20,L=10, epsilon=1e-4, n.max=1000, b.update.order=1,upperGroupSize = NULL, p=NULL)
{

  offsetrow=0; offsetcol=0; transposeX=FALSE
  YT=t(Y)
  XT=t(X)
  XI=X
  n = nrow(Y)
  q = ncol(Y)
  p = ncol(X)
  if(is.matrix(X)){
    if(nrow(X) !=n ){
      stop("dimensions of y and X do not match!\n")
    }
    p = ncol(X)
  }else if(is.character(X)){
    if(file.access(X, mode = 0)!=0){
      stop(X, "is not a valid file name.\n")
    }
    if(is.null(p)){
      stop("when X is a file name, p must be specified\n")
    }
  }else{
    stop("X must be either a data matrix or a valid input file name.\n")
  }
 
  if(is.null(BIC.gamma)){
    BIC.gamma = 1 - 1/(2*log(p)/log(n))
  }
  if(BIC.gamma > 1 | BIC.gamma < 0){
    stop("BIC.gamma must in the range of [0,1]\n")
  }
  
  if(is.null(b)){
    b=matrix(0,p,q)
    
  }else{
    if(ncol(b) != p){
      stop("length of b is different from number of columns of X\n")
    } 
  }

  if(is.null(IAL_bS)){
    IAL_bS = matrix(0,p,q)
  }
  
  if(is.null(upperGroupSize)){
    upperGroupSize = ceiling(sqrt(n))
  }
  # ------------------------------------------------------- 
  # preparation for C code
  # -------------------------------------------------------
  J=matrix(,p,q)
  for(i in 1:q){
    J[,i]=sample(c(0:(p-1)))
  }
  I=sample(c(0:(q-1)))

  n.iter  = 0
  bSample = matrix(0,p,q)
  b0      = rep(0,q)

  score = rep(0, length(tau1))
  scoNA = rep(1, length(tau1))
  
  leng= length(tau1)
  Bva = matrix(0,pMax*q,leng)
  Bin1 = matrix(0,pMax*q,leng)
  Bin2 = matrix(0,pMax*q,leng)
  v0m  = matrix(0,q, leng)
  b0m  = matrix(0,q, leng)
  
  
  dims = c(n, p, L, n.max, !is.null(b), offsetrow, offsetcol, transposeX)
  dims = c(dims, length(tau1), length(delta2), (pMax), cv, q, length(tau1), length(tau2), upperGroupSize)
  
  score2use = delta1use = delta2use = tau1use = tau2use=-9999.9999
  
    # ------------------------------------------------------- 
  # If use cross-validation to select variables
  # idc is indicator of the cv groups
  # -------------------------------------------------------
  sam = sample(n)
  nb  = n %% cv
  na  = cv - nb
  nk  = floor(n/cv)
  nob = c(rep(nk,na), rep(nk+1,nb))
  idc = rep(0:(cv-1), each=nob)
  idc = sample(idc)

  # ------------------------------------------------------- 
  # preparation for C code
  # -------------------------------------------------------

  if(is.character(X)){
    Z = .C("MPENc", Y=as.double(Y), as.character(X),as.double(t(b)),
      bSample = as.double(t(bSample)), b0 = as.double(b0),
      as.double(delta1), as.double(delta2),as.double(tau1),as.double(tau2), as.integer(dims),
      as.double(epsilon), n.iter=as.integer(n.iter),
      as.integer(b.update.order), score=as.double(score),
      scoNA=as.integer(scoNA),  as.double(BIC.gamma), 
      as.integer(idc), as.character(Choosing_Tuning1), as.character(Choosing_Tuning2),
      score2use=as.double(score2use), delta1use=as.double(delta1use),
      delta2use=as.double(delta2use), tau1use=as.double(tau1use),
      tau2use=as.double(tau2use),v0m=as.double(t(v0m)),b0m=as.double(t(b0m)),J=as.integer(t(J)),
      I=as.integer(I),PACKAGE="MPEN")
  }else{
    Z = .C("MPENr", Y=as.double(Y), X=as.double(X),b=as.double(t(b)), 
      bSample = as.double(t(bSample)), b0 = as.double(b0),
      as.double(delta1), as.double(delta2),as.double(tau1),as.double(tau2), as.integer(dims),
      as.double(epsilon), n.iter=as.integer(n.iter),
      as.integer(b.update.order), score=as.double(score),
      scoNA=as.integer(scoNA),  as.double(BIC.gamma), 
      as.integer(idc), as.character(Choosing_Tuning1), as.character(Choosing_Tuning2),
      score2use=as.double(score2use), delta1use=as.double(delta1use),
      delta2use=as.double(delta2use), tau1use=as.double(tau1use),
      tau2use=as.double(tau2use),v0m=as.double(t(v0m)),b0m=as.double(t(b0m)),J=as.integer(t(J)),
      I=as.integer(I),PACKAGE="MPEN")
  }
  
  #----------------------------------------------------
  # score = matrix(Z$score, nrow=length(delta), ncol=length(tau), byrow=TRUE)
  # scoNA = matrix(Z$scoNA, nrow=length(delta), ncol=length(tau), byrow=TRUE)
  # score[scoNA==1] = NA
  # if(all(is.na(as.vector(score)))){
  #  warning("no acceptable delta/tau are found\n")
  #  return(NULL)
  #}
  #-----------------------------------------------------
  
  
  if(n.iter>=n.max){warning("The algorithm doesn't converge\n")}
  b0 = matrix(Z$b0,1,q,byrow=TRUE)
  bS = matrix(Z$bSample,p,q,byrow=TRUE)
  
  delta1 = Z$delta1use
  delta2  = Z$delta2use
  tau1 = Z$tau1use
  tau2 = Z$tau2use
  bSindex= which(bS!=0)
  bSestimates = bS[bSindex]

  ll = list(bSindex=bSindex, bSestimates = bSestimates, b0=b0, delta1=delta1, delta2=delta2, tau1=tau1, tau2=tau2)
  class(ll) = "MPEN"
  rm(Z, bS, Y, X)
  ll
  
}
