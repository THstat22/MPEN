.First.lib <- function(lib, pkg) {
  library.dynam("MPEN", pkg, lib)
}
